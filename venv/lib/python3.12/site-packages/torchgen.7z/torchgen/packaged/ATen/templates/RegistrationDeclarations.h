// This file contains all native_functions that can be registered to
// and the schema string that they should be registered with

${registration_declarations}
