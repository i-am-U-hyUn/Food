#include <torch/csrc/autograd/generated/ViewFuncs.h>

// ${generated_comment}

using at::Tensor;
using at::Scalar;
using at::IntArrayRef;
using at::TensorList;

namespace torch::autograd::generated {

${view_func_definitions}

} // namespace torch::autograd::generated
