from . import eigen           # to set methods
from . import eigen_symmetric # to set methods
